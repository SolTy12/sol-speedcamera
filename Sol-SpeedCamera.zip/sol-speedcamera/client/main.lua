local QBCore = nil
local ESX = nil
local SpeedCameras = {}
local SpawnedProps = {}
local RecentlyFined = false

CreateThread(function()
    if Config.Framework == 'auto' or Config.Framework == 'qb' then
        if GetResourceState('qb-core') == 'started' then
            QBCore = exports['qb-core']:GetCoreObject()
        end
    end
    if (Config.Framework == 'auto' and not QBCore) or Config.Framework == 'esx' then
        if GetResourceState('es_extended') == 'started' then
            ESX = exports['es_extended']:getSharedObject()
        end
    end

    -- Request cameras from server on join / resource start
    TriggerServerEvent('sol-speedcamera:server:requestCameras')
end)

-- Function to spawn a camera prop
local function SpawnCameraProp(camParams)
    local hash = GetHashKey(Config.CameraProp)
    RequestModel(hash)
    while not HasModelLoaded(hash) do Wait(10) end

    local prop = CreateObject(hash, camParams.coords.x, camParams.coords.y, camParams.coords.z - 1.0, false, false, false)
    SetEntityHeading(prop, camParams.heading)
    FreezeEntityPosition(prop, true)
    
    SpawnedProps[camParams.id] = prop
end

-- Sync all cameras from server
RegisterNetEvent('sol-speedcamera:client:syncCameras', function(cams)
    for id, prop in pairs(SpawnedProps) do
        if DoesEntityExist(prop) then DeleteEntity(prop) end
    end
    SpawnedProps = {}
    SpeedCameras = cams

    for _, cam in ipairs(SpeedCameras) do
        SpawnCameraProp(cam)
    end
end)

-- Add single camera
RegisterNetEvent('sol-speedcamera:client:addCamera', function(cam)
    table.insert(SpeedCameras, cam)
    SpawnCameraProp(cam)
end)

-- Remove single camera
RegisterNetEvent('sol-speedcamera:client:removeCamera', function(cameraId)
    for i, cam in ipairs(SpeedCameras) do
        if cam.id == cameraId then
            table.remove(SpeedCameras, i)
            break
        end
    end

    if SpawnedProps[cameraId] then
        if DoesEntityExist(SpawnedProps[cameraId]) then
            DeleteEntity(SpawnedProps[cameraId])
        end
        SpawnedProps[cameraId] = nil
    end
end)

-- Detection Thread
CreateThread(function()
    while true do
        local sleep = 500
        local ped = PlayerPedId()

        if IsPedInAnyVehicle(ped, false) and GetPedInVehicleSeat(GetVehiclePedIsIn(ped, false), -1) == ped then
            if not RecentlyFined then
                local vehicle = GetVehiclePedIsIn(ped, false)
                local currentCoords = GetEntityCoords(vehicle)
                local speedRaw = GetEntitySpeed(vehicle)
                local currentSpeed = Config.SpeedUnit == 'kmh' and (speedRaw * 3.6) or (speedRaw * 2.236936)

                for _, cam in ipairs(SpeedCameras) do
                    local dist = #(currentCoords - vec3(cam.coords.x, cam.coords.y, cam.coords.z))
                    if dist <= Config.DetectionRadius then
                        sleep = 50 -- Check faster when near

                        if currentSpeed > (cam.limit + 2.0) then -- +2.0 buffer
                            local forwardVector = GetEntityForwardVector(vehicle)
                            local cHeading = cam.heading
                            -- Optional: we can check if they are facing the camera or just in radius.
                            -- For simplicity, if they are in radius and speeding, they get flashed.
                            
                            -- Effect
                            PlaySoundFrontend(-1, "Camera_Shoot", "Phone_Soundset_Default", false)
                            AnimpostfxPlay("CameraFlash", 0, false)
                            CreateThread(function()
                                local alpha = 250
                                while alpha > 0 do
                                    Wait(0)
                                    alpha = alpha - 15
                                    if alpha < 0 then alpha = 0 end
                                    DrawRect(0.5, 0.5, 1.0, 1.0, 255, 255, 255, alpha)
                                end
                            end)
                            
                            TriggerServerEvent('sol-speedcamera:server:issueFine', cam.limit, currentSpeed)
                            
                            RecentlyFined = true
                            SetTimeout(Config.Cooldown, function() RecentlyFined = false end)
                            break
                        end
                    end
                end
            end
        end

        Wait(sleep)
    end
end)

-- Notification
RegisterNetEvent('sol-speedcamera:client:notifyFine', function(limit, speed, fine)
    local msg = _U('speeding_fine', limit, math.floor(speed), fine)
    if Config.NotifyType == 'ox_lib' then
        lib.notify({ title = _U('fine_subject'), description = msg, type = 'error' })
    elseif Config.NotifyType == 'qb' and QBCore then
        QBCore.Functions.Notify(msg, 'error')
    elseif Config.NotifyType == 'esx' and ESX then
        ESX.ShowNotification(msg)
    else
        SetNotificationTextEntry("STRING")
        AddTextComponentString(msg)
        DrawNotification(false, false)
    end
end)

-- Admin Menu for Placing
RegisterNetEvent('sol-speedcamera:client:openPlaceCamMenu', function()
    local input = lib.inputDialog(_U('speed_limit_input_title'), {
        {type = 'number', label = _U('speed_limit_input_label'), description = 'e.g., 80', required = true, min = 1}
    })

    if not input then return end
    if not input[1] then return end

    local limit = tonumber(input[1])
    if limit and limit > 0 then
        local ped = PlayerPedId()
        local coords = GetEntityCoords(ped)
        local heading = GetEntityHeading(ped)
        
        -- Offset slightly forward so it doesn't spawn exactly on the admin
        local forwardX = coords.x + (math.sin(-heading * math.pi / 180.0) * 1.5)
        local forwardY = coords.y + (math.cos(-heading * math.pi / 180.0) * 1.5)
        
        local spawnCoords = vec3(forwardX, forwardY, coords.z)
        
        TriggerServerEvent('sol-speedcamera:server:placeCamera', spawnCoords, heading, limit)
        lib.notify({ title = 'Success', description = _U('speed_camera_placed', limit), type = 'success' })
    else
        lib.notify({ title = 'Error', description = _U('invalid_speed'), type = 'error' })
    end
end)

-- Admin Remove Camera
RegisterNetEvent('sol-speedcamera:client:tryRemoveCam', function()
    local ped = PlayerPedId()
    local coords = GetEntityCoords(ped)
    
    local closestDist = 5.0
    local closestId = nil

    for _, cam in ipairs(SpeedCameras) do
        local dist = #(coords - vec3(cam.coords.x, cam.coords.y, cam.coords.z))
        if dist < closestDist then
            closestDist = dist
            closestId = cam.id
        end
    end

    if closestId then
        TriggerServerEvent('sol-speedcamera:server:removeCamera', closestId)
    else
        lib.notify({ title = 'Error', description = _U('no_camera_nearby'), type = 'error' })
    end
end)
