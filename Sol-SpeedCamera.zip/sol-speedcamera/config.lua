Config = {}

-- Select framework ('qb', 'esx', or 'auto' to auto-detect)
Config.Framework = 'auto' 

Config.Locale = 'he' -- Language file to use ('he' or 'en')

Config.CameraProp = 'speed'

-- Minimum time in ms between fines for the same player to avoid spam
Config.Cooldown = 5000

-- Detection distance
Config.DetectionRadius = 25.0

-- Command Config
Config.AdminCommand = 'placecam'
Config.RemoveCommand = 'removecam'
Config.AdminGroups = {
    ['admin'] = true,
    ['god'] = true,
    ['superadmin'] = true
}

-- The fine amount is calculated as: (PlayerSpeed - SpeedLimit) * Config.FineMultiplier
-- Or a flat amount if you prefer. Here we use a flat amount per km/h over the limit.
Config.FineMultiplier = 10 -- e.g., 20 km/h over limit = 200$ fine
Config.MinimumFine = 100 -- the minimum fine they get if caught
Config.MaxFine = 5000    -- the maximum fine possible

-- Billing configuration
-- Options: 'auto_deduct' (takes money right away), 'qb_default' (qb-phone invoice), 'esx_billing', 'okokBilling', 'peleg_billing'
Config.BillingSystem = 'peleg_billing'
Config.PoliceSociety = 'police' -- Which job receives the fine money

-- Notification settings
Config.NotifyType = 'ox_lib' -- 'ox_lib', 'qb', 'esx'

-- Allowed speed unit
Config.SpeedUnit = 'kmh' -- 'kmh' or 'mph'

-- Localization Helper
function _U(str, ...)
    local locale = Config.Locale or 'en'
    if Locales and Locales[locale] and Locales[locale][str] then
        return string.format(Locales[locale][str], ...)
    end
    return 'Translation missing for: ' .. str
end
