local QBCore = nil
local ESX = nil

-- Setup Framework
CreateThread(function()
    if Config.Framework == 'auto' or Config.Framework == 'qb' then
        if GetResourceState('qb-core') == 'started' then
            QBCore = exports['qb-core']:GetCoreObject()
            print('[sol-speedcamera] QBCore detected and loaded.')
        end
    end
    
    if (Config.Framework == 'auto' and not QBCore) or Config.Framework == 'esx' then
        if GetResourceState('es_extended') == 'started' then
            ESX = exports['es_extended']:getSharedObject()
            print('[sol-speedcamera] ESX detected and loaded.')
        end
    end
end)

-- Global array to store cameras in memory
local SpeedCameras = {}

-- Load cameras from JSON
CreateThread(function()
    local loadFile = LoadResourceFile(GetCurrentResourceName(), "cameras.json")
    if loadFile then
        local decoded = json.decode(loadFile)
        if decoded then
            SpeedCameras = decoded
        end
    end
end)

-- Function to save cameras to JSON
local function SaveCamerasToFile()
    SaveResourceFile(GetCurrentResourceName(), "cameras.json", json.encode(SpeedCameras, {indent = true}), -1)
end

-- Callback / Event to get cameras on client join
RegisterNetEvent('sol-speedcamera:server:requestCameras', function()
    local src = source
    TriggerClientEvent('sol-speedcamera:client:syncCameras', src, SpeedCameras)
end)

-- Event to place a camera
RegisterNetEvent('sol-speedcamera:server:placeCamera', function(coords, heading, speedLimit)
    local src = source
    -- Quick permission check
    if not IsPlayerAdmin(src) then
        TriggerClientEvent('ox_lib:notify', src, { title = 'Error', description = _U('no_permissions'), type = 'error' })
        return
    end

    local newCam = {
        id = os.time() .. math.random(1000, 9999), -- Unique ID
        coords = coords,
        heading = heading,
        limit = speedLimit
    }
    
    table.insert(SpeedCameras, newCam)
    SaveCamerasToFile()

    -- Sync to all clients
    TriggerClientEvent('sol-speedcamera:client:addCamera', -1, newCam)
end)

-- Event to remove a camera
RegisterNetEvent('sol-speedcamera:server:removeCamera', function(cameraId)
    local src = source
    if not IsPlayerAdmin(src) then return end

    local removed = false
    for i, cam in ipairs(SpeedCameras) do
        if cam.id == cameraId then
            table.remove(SpeedCameras, i)
            removed = true
            break
        end
    end

    if removed then
        SaveCamerasToFile()
        TriggerClientEvent('sol-speedcamera:client:removeCamera', -1, cameraId)
        TriggerClientEvent('ox_lib:notify', src, { title = 'Success', description = _U('speed_camera_removed'), type = 'success' })
    end
end)

-- Handle Fines
RegisterNetEvent('sol-speedcamera:server:issueFine', function(cameraLimit, playerSpeed)
    local src = source
    local overLimit = math.floor(playerSpeed - cameraLimit)
    
    if overLimit <= 0 then return end -- sanity check

    local fineAmount = math.floor(overLimit * Config.FineMultiplier)
    if fineAmount < Config.MinimumFine then fineAmount = Config.MinimumFine end
    if fineAmount > Config.MaxFine then fineAmount = Config.MaxFine end

    -- Handle Billing
    local issued = false

    if Config.BillingSystem == 'auto_deduct' then
        if QBCore then
            local Player = QBCore.Functions.GetPlayer(src)
            if Player then
                Player.Functions.RemoveMoney('bank', fineAmount, 'speed-camera-fine')
                issued = true
            end
        elseif ESX then
            local xPlayer = ESX.GetPlayerFromId(src)
            if xPlayer then
                xPlayer.removeAccountMoney('bank', fineAmount)
                issued = true
            end
        end
    elseif Config.BillingSystem == 'okokBilling' then
        -- Default okokBilling
        if QBCore then
            local Player = QBCore.Functions.GetPlayer(src)
            if Player then
                TriggerEvent("okokBilling:server:CreateCustomInvoice", src, fineAmount, "דוח מהירות", "Camera", Config.PoliceSociety, "Police")
                issued = true
            end
        elseif ESX then
            -- ESX variant of okokBilling
            TriggerEvent("okokBilling:server:CreateCustomInvoice", src, fineAmount, "דוח מהירות", "Camera", Config.PoliceSociety, "Police")
            issued = true
        end
    elseif Config.BillingSystem == 'esx_billing' then
        if ESX then
            TriggerEvent('esx_billing:sendBill', src, 'society_' .. Config.PoliceSociety, 'דוח מהירות - מצלמה', fineAmount)
            issued = true
        end
    elseif Config.BillingSystem == 'qb_default' then
        if QBCore then
            local Player = QBCore.Functions.GetPlayer(src)
            if Player then
                -- Often qb-phone uses this table structure:
                MySQL.Async.insert('INSERT INTO phone_invoices (citizenid, amount, society, sender, sendercitizenid) VALUES (?, ?, ?, ?, ?)',
                    {Player.PlayerData.citizenid, fineAmount, Config.PoliceSociety, "משטרת התנועה", "12345"})
                TriggerClientEvent('qb-phone:client:CustomNotification', src,
                    "משטרת התנועה", "קיבלת חשבונית על נסיעה מופרזת", "fas fa-file-invoice-dollar", "#e84118", 5000)
                issued = true
            end
        end
    elseif Config.BillingSystem == 'peleg_billing' then
        local targetCid = nil
        local targetName = nil

        if QBCore then
            local Player = QBCore.Functions.GetPlayer(src)
            if Player then
                targetCid = Player.PlayerData.citizenid
                targetName = Player.PlayerData.charinfo.firstname .. ' ' .. Player.PlayerData.charinfo.lastname
            end
        elseif ESX then
            local xPlayer = ESX.GetPlayerFromId(src)
            if xPlayer then
                targetCid = xPlayer.identifier
                targetName = xPlayer.getName()
            end
        end

        if QBCore or ESX then
            -- We use the player as both issuer and target to satisfy peleg-billing's requirement for an online source
            local billId = exports['peleg-billing']:CreateBill(src, src, Config.PoliceSociety, fineAmount, "דוח מצלמת מהירות", "bank")
            if billId then
                issued = true
            else
                print("[sol-speedcamera] ERR: peleg-billing CreateBill failed for src " .. tostring(src))
            end
        end
    end

    if issued then
        TriggerClientEvent('sol-speedcamera:client:notifyFine', src, cameraLimit, playerSpeed, fineAmount)
    end
end)

-- Helper to check if admin
function IsPlayerAdmin(source)
    if QBCore then
        local p = QBCore.Functions.GetPlayer(source)
        if p and p.PlayerData.role and (p.PlayerData.role == 'admin' or p.PlayerData.role == 'god') then
            return true
        end
        if QBCore.Functions.HasPermission(source, 'admin') then return true end
    elseif ESX then
        local p = ESX.GetPlayerFromId(source)
        if p and p.getGroup() then
            if Config.AdminGroups[p.getGroup()] then
                return true
            end
        end
    end
    -- Fallback via principal
    if IsPlayerAceAllowed(source, 'command') then return true end
    
    return false
end

-- Commands
RegisterCommand(Config.AdminCommand, function(source, args, rawCommand)
    local src = source
    if src == 0 then return end
    if IsPlayerAdmin(src) then
        TriggerClientEvent('sol-speedcamera:client:openPlaceCamMenu', src)
    else
        TriggerClientEvent('ox_lib:notify', src, { title = 'Error', description = _U('no_permissions'), type = 'error' })
    end
end, false)

RegisterCommand(Config.RemoveCommand, function(source, args, rawCommand)
    local src = source
    if src == 0 then return end
    if IsPlayerAdmin(src) then
        TriggerClientEvent('sol-speedcamera:client:tryRemoveCam', src)
    else
        TriggerClientEvent('ox_lib:notify', src, { title = 'Error', description = _U('no_permissions'), type = 'error' })
    end
end, false)
