fx_version 'cerulean'
games { 'gta5' }

author 'Sol'
description 'Speed Camera Based on israeli speed cameras'
version '1.0.0'

shared_script '@ox_lib/init.lua'

client_scripts {
    'config.lua',
    'locales/he.lua',
    'locales/en.lua',
    'client/main.lua'
}

server_scripts {
    'config.lua',
    'locales/he.lua',
    'locales/en.lua',
    'server/main.lua'
}

-- Declare json file for saving (technically handled by SaveResourceFile, but good context)
file 'cameras.json'
