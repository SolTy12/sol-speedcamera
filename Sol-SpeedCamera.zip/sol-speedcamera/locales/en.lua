Locales = Locales or {}

Locales['en'] = {
    ['speed_camera_placed'] = 'Speed camera placed successfully (Limit: %s)!',
    ['speed_camera_removed'] = 'Speed camera removed!',
    ['no_permissions'] = 'You do not have permission to use this command.',
    ['speed_limit_input_title'] = 'Enter Speed Limit for Camera',
    ['speed_limit_input_label'] = 'Speed Limit',
    ['invalid_speed'] = 'Invalid speed entered!',
    ['speeding_fine'] = 'You were fined for speeding!\nYou were doing %s in a %s zone.\nYou have been fined $%s.',
    ['fine_subject'] = 'Speeding Ticket',
    ['no_camera_nearby'] = 'No speed camera found nearby to remove.',
    ['cant_afford_fine'] = 'You could not afford the fine, money was deducted anyway.'
}
