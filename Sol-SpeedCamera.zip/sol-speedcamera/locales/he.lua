Locales = Locales or {}

Locales['he'] = {
    ['speed_camera_placed'] = 'הנחת מצלמת מהירות בהצלחה (מגבלה: %s)!',
    ['speed_camera_removed'] = 'מצלמת מהירות הוסרה!',
    ['no_permissions'] = 'אין לך גישה לפקודה זו.',
    ['speed_limit_input_title'] = 'הזן מהירות מוגבלת למצלמה',
    ['speed_limit_input_label'] = 'מהירות',
    ['invalid_speed'] = 'מהירות לא תקינה!',
    ['speeding_fine'] = 'קיבלת דוח על נסיעה מופרזת!\nעברת את מגבלת ה-%s ונסעת על %s.\nנקנסת ב-%s$.',
    ['fine_subject'] = 'דוח מהירות',
    ['no_camera_nearby'] = 'לא נמצאה מצלמת מהירות קרובה כדי להסיר.',
    ['cant_afford_fine'] = 'אין בחשבונך מספיק כסף לתשלום מלא של הדוח, המינוס שלך גדל.'
}
