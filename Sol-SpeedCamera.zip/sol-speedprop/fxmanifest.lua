fx_version 'cerulean'
game 'gta5'

author 'Zoovdev'
description 'FiveM asset resource created with zoov.dev'
version '1.0.0'


data_file 'DLC_ITYP_REQUEST' 'stream/speed.ytyp'